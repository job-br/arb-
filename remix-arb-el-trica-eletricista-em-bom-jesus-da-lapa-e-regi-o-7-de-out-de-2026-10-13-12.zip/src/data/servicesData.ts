export interface ServiceItem {
  id: string;
  category: 'predial-residencial' | 'eletrotecnica-comandos' | 'infraestrutura-redes';
  categoryLabel: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  icon: string;
  badge?: string;
  popular?: boolean;
}

export const PHONE_NUMBER = '+557798149375';
export const PHONE_DISPLAY = '(77) 9814-9375';
export const WHATSAPP_NUMBER = '557798149375';
export const EMAIL_ADDRESS = 'eletec.barros@gmail.com';
export const INSTAGRAM_URL = 'https://www.instagram.com/dennis7.0/';
export const FACEBOOK_URL = 'https://www.facebook.com/profile.php?id=100073836716922';

export const CITIES_SERVED = [
  { name: 'Bom Jesus da Lapa', distance: 'Sede (Atendimento Imediato)', state: 'BA', icon: '📍' },
  { name: 'Serra do Ramalho', distance: 'Aprox. 35 km', state: 'BA', icon: '⚡' },
  { name: 'Sítio do Mato', distance: 'Aprox. 45 km', state: 'BA', icon: '⚡' },
  { name: 'Riacho de Santana', distance: 'Aprox. 65 km', state: 'BA', icon: '⚡' },
  { name: 'Paratinga', distance: 'Aprox. 70 km', state: 'BA', icon: '⚡' },
  { name: 'Igaporã', distance: 'Aprox. 80 km', state: 'BA', icon: '⚡' },
  { name: 'Macaúbas', distance: 'Aprox. 100 km', state: 'BA', icon: '⚡' },
  { name: 'Projeto Formoso & Zona Rural', distance: 'Raio de 100 km', state: 'BA', icon: '🚜' },
];

export const SERVICES_LIST: ServiceItem[] = [
  // 🏢 Elétrica Predial e Residencial
  {
    id: 'instalacoes-completas',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Instalações Elétricas Completas',
    shortDesc: 'Infraestrutura estrutural do zero, passagem de cabos e fiação geral com projeto e segurança.',
    fullDesc: 'Execução de obras elétricas residenciais e comerciais completas, desde a fase de alvenaria até o acabamento fino. Tubulação, passagem de condutores dimensionados pela NBR 5410, conexões estanques e teste de isolamento.',
    features: [
      'Infraestrutura estrutural do zero',
      'Passagem de cabos com dimensionamento térmico e de queda de tensão',
      'Fiação geral com condutores antichama normatizados',
      'Projetos para residências, comércios e galpões'
    ],
    icon: 'Cable',
    badge: 'Mais Solicitado',
    popular: true,
  },
  {
    id: 'manutencao-preventiva-corretiva',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Manutenção Preventiva e Corretiva',
    shortDesc: 'Diagnóstico preciso de falhas, reparos de curtos-circuitos e troca urgente de fiação antiga.',
    fullDesc: 'Identificação imediata da causa raiz de desarmes de disjuntores, superaquecimento de tomadas, cheiro de queimado e queima frequente de eletrodomésticos. Substituição de condutores ressecados e fiação antiga.',
    features: [
      'Diagnóstico de falhas com instrumentação profissional',
      'Localização e reparo de curto-circuito sem quebrar paredes desnecessariamente',
      'Troca de fiação antiga ressecada ou fora de norma',
      'Revisão geral para evitar incêndios elétricos'
    ],
    icon: 'Wrench',
    badge: 'Segurança Máxima',
    popular: true,
  },
  {
    id: 'montagem-manutencao-qdg',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Montagem e Manutenção de QDG',
    shortDesc: 'Montagem completa de Quadros de Distribuição Geral, disjuntores termomagnéticos e barramentos.',
    fullDesc: 'O coração da instalação elétrica. Montagem organizada de QDG com divisão correta de circuitos (iluminação, tomadas de uso geral TUG e tomadas específicas TUE), barramentos tipo pente e identificação de circuitos.',
    features: [
      'Montagem completa de Quadros de Distribuição Geral (QDG)',
      'Dimensionamento de disjuntores termomagnéticos DIN',
      'Barramentos tipo pente fase, neutro e terra organizados',
      'Identificação e anilhamento de todos os circuitos'
    ],
    icon: 'Cpu',
    badge: 'Essencial',
    popular: true,
  },
  {
    id: 'instalacao-iluminacao',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Instalação de Iluminação & LED',
    shortDesc: 'Projetos luminotécnicos com LED, luminárias, lustres finos, spots, fitas LED e sensores.',
    fullDesc: 'Instalação moderna e estilosa de iluminação decorativa e funcional. Fitas LED com fontes ocultas, spots de embutir em gesso, perfis de LED, lustres pendentes, refletores externos e sensores de presença para economia de energia.',
    features: [
      'Projetos de LED modernos e de alta eficiência',
      'Luminárias, lustres e pendentes de design',
      'Spots de embutir e sobrepor em forros de gesso ou PVC',
      'Fitas LED com perfil de alumínio e sensores de presença'
    ],
    icon: 'Lightbulb',
  },
  {
    id: 'padrao-entrada-energia',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Padrão de Entrada de Energia',
    shortDesc: 'Montagem e adequação de padrão de entrada conforme as normas da concessionária de energia.',
    fullDesc: 'Instalação e regularização de caixas de medição monofásicas, bifásicas e trifásicas de acordo com as exigências técnicas da Neoenergia Coelba. Troca de ramais de entrada e aumento de carga.',
    features: [
      'Montagem de padrão de entrada monofásico, bifásico e trifásico',
      'Adequação e reforma de padrão antigo conforme normas da Coelba',
      'Aumento de carga para ar-condicionado e máquinas',
      'Aterramento do padrão com haste cobreada e caixa de inspeção'
    ],
    icon: 'ShieldCheck',
    badge: 'Norma Técnica',
    popular: true,
  },
  {
    id: 'instalacao-equipamentos',
    category: 'predial-residencial',
    categoryLabel: 'Elétrica Predial e Residencial',
    title: 'Instalação de Equipamentos & TUE',
    shortDesc: 'Chuveiros, torneiras elétricas, ventiladores de teto, exaustores e tomadas dedicadas de alta potência.',
    fullDesc: 'Instalação segura com fiação dedicada e disjuntor exclusivo para cargas de alta potência, evitando sobrecarga na rede e garantindo banhos quentes sem queimar fios nem desarmar disjuntor.',
    features: [
      'Chuveiros e duchas elétricas e eletrônicas de alta potência',
      'Torneiras elétricas e aquecedores de pia',
      'Ventiladores de teto com controle remoto ou dimmer',
      'Tomadas especiais de 20A para ar-condicionado, fornos e micro-ondas'
    ],
    icon: 'Plug',
  },

  // 🔧 Eletrotécnica e Comandos
  {
    id: 'quadros-comando-automacao',
    category: 'eletrotecnica-comandos',
    categoryLabel: 'Eletrotécnica e Comandos',
    title: 'Quadros de Comando e Automação',
    shortDesc: 'Montagem, automação e manutenção de quadros elétricos de comando para indústria e comércios.',
    fullDesc: 'Desenvolvimento e montagem de painéis de comando completos: contatores, relés térmicos, temporizadores, botoeiras, sinaleiros, CLPs e partidas de motores elétricos. Diagnóstico e reforma de painéis desorganizados.',
    features: [
      'Montagem de quadros elétricos de comando industrial e predial',
      'Automação de processos e acionamentos temporizados',
      'Partida direta, estrela-triângulo e com soft-starter/inversor',
      'Painéis em caixa metálica com proteção IP adequada'
    ],
    icon: 'Sliders',
    badge: 'Especialista',
    popular: true,
  },
  {
    id: 'manutencao-motores-bombas',
    category: 'eletrotecnica-comandos',
    categoryLabel: 'Eletrotécnica e Comandos',
    title: 'Manutenção de Motores e Bombas d\'Água',
    shortDesc: 'Ligação, reversão, proteção e automação de motores elétricos e bombas de água para irrigação e prédios.',
    fullDesc: 'Solução completa para sistemas de bombeamento e motores elétricos em fazendas, irrigação, poços artesianos e condomínios da região de Bom Jesus da Lapa. Automação com boias automáticas e relé falta de fase.',
    features: [
      'Ligação e teste de isolamento de motores elétricos mono e trifásicos',
      'Automação e proteção de bombas d\'água de poços e reservatórios',
      'Sistemas de reversão de rotação e acionamento inteligente',
      'Proteção contra falta de fase e sobrecarga mecânica'
    ],
    icon: 'Gauge',
    badge: 'Agronegócio & Prédios',
    popular: true,
  },
  {
    id: 'sistemas-protecao-dps-dr',
    category: 'eletrotecnica-comandos',
    categoryLabel: 'Eletrotécnica e Comandos',
    title: 'Sistemas de Proteção: IDR, DPS e Aterramento',
    shortDesc: 'Instalação e testes de IDR (DR antichoque), DPS (proteção contra raios/surtos) e malha de aterramento.',
    fullDesc: 'Proteja vidas e equipamentos caros. O IDR desliga instantaneamente em caso de fuga de corrente (evitando choques fatais), enquanto o DPS desvia surtos de tensão causados por descargas atmosféricas (raios).',
    features: [
      'Instalação de IDR (Interruptor Diferencial Residual) obrigatório pela NBR 5410',
      'Dispositivo de Proteção contra Surtos (DPS) contra queima por raios',
      'Medição e execução de malha de aterramento com hastes de cobre',
      'Eliminação de fuga de energia que aumenta a conta de luz'
    ],
    icon: 'Shield',
    badge: 'Vida & Patrimônio',
    popular: true,
  },
  {
    id: 'correcao-fator-potencia',
    category: 'eletrotecnica-comandos',
    categoryLabel: 'Eletrotécnica e Comandos',
    title: 'Correção de Fator de Potência',
    shortDesc: 'Análise e instalação de banco de capacitores para eliminação de multas por energia reativa.',
    fullDesc: 'Economize milhares de reais na fatura de energia da sua empresa, oficina ou indústria. Projetamos e instalamos bancos de capacitores automáticos ou fixos para corrigir o fator de potência e anular a cobrança de excedente reativo.',
    features: [
      'Análise de grandezas elétricas e cobrança de excedente reativo',
      'Instalação de banco de capacitores fixo ou automático',
      'Redução do desperdício de energia e aquecimento de condutores',
      'Retorno rápido do investimento através da economia na conta'
    ],
    icon: 'TrendingDown',
    badge: 'Economia na Conta',
  },

  // 🌐 Redistribuição e Infraestrutura
  {
    id: 'redistribuicao-cargas',
    category: 'infraestrutura-redes',
    categoryLabel: 'Redistribuição e Infraestrutura',
    title: 'Redistribuição e Balanceamento de Cargas',
    shortDesc: 'Balanceamento de fases em redes bifásicas e trifásicas para evitar sobrecarga e quedas de energia.',
    fullDesc: 'Quando uma fase consome muito mais do que as outras, ocorrem quedas de tensão, queima de disjuntores e perda de eficiência. O balanceamento distribui os circuitos equilibradamente entre as fases R, S e T.',
    features: [
      'Medição de corrente fase a fase com amperímetro calibrado',
      'Balanceamento ideal em redes bifásicas e trifásicas',
      'Eliminação de quedas repentinas de energia e oscilações de luz',
      'Aumento da vida útil de eletrodomésticos e motores'
    ],
    icon: 'Scale',
  },
  {
    id: 'infraestrutura-eletrocalhas',
    category: 'infraestrutura-redes',
    categoryLabel: 'Redistribuição e Infraestrutura',
    title: 'Infraestrutura de Eletrocalhas e Perfilados',
    shortDesc: 'Instalação de eletrocalhas, perfilados, eletrodutos galvanizados e canaletas para passagens de cabos.',
    fullDesc: 'Montagem de infraestrutura aparente robusta e estética para indústrias, comércios, lojas, supermercados e galpões. Passagem organizada e protegida de cabos de força, comando e dados.',
    features: [
      'Instalação de eletrocalhas perfuradas ou lisas com suspensão reforçada',
      'Montagem de perfilados metálicos com luminárias integradas',
      'Eletrodutos de aço galvanizado à prova de impacto e poeira',
      'Canaletas de alta durabilidade para organização e estética'
    ],
    icon: 'Layers',
  },
];

export const TESTIMONIALS = [
  {
    name: 'Carlos Eduardo Mendes',
    role: 'Proprietário Comercial - Bom Jesus da Lapa',
    text: 'A ARB Elétrica fez toda a reforma do quadro de comando e a redistribuição de cargas da minha padaria. Nunca mais tivemos problemas de disjuntor caindo nem queima de motores. Serviço pontual e extremamente caprichado!',
    rating: 5,
    location: 'Centro, Bom Jesus da Lapa - BA',
  },
  {
    name: 'Marcos Vinícius Silva',
    role: 'Produtor Rural - Serra do Ramalho',
    text: 'Precisava de um eletrotécnico de confiança para automatizar o sistema de bombeamento de água da propriedade. O Dennis veio até aqui em Serra do Ramalho, instalou a proteção com relé e resolveu perfeitamente. Recomendo muito!',
    rating: 5,
    location: 'Serra do Ramalho - BA',
  },
  {
    name: 'Luciana Ferreira',
    role: 'Residencial - Bom Jesus da Lapa',
    text: 'Instalou toda a iluminação em LED da minha casa, trocou o quadro antigo e colocou DPS e DR de proteção. Ficou tudo muito organizado e limpo. Dá gosto de ver a qualidade do acabamento!',
    rating: 5,
    location: 'São Gotardo, Bom Jesus da Lapa - BA',
  },
  {
    name: 'Antônio José Ribeiro',
    role: 'Empresário - Riacho de Santana',
    text: 'Atendimento muito ágil! Estávamos pagando multa de energia reativa e com a instalação do banco de capacitores pela ARB Elétrica nossa conta reduziu drasticamente no mês seguinte. Profissional que entende de verdade do assunto.',
    rating: 5,
    location: 'Riacho de Santana - BA',
  },
];

export const FAQ_ITEMS = [
  {
    question: 'Como faço para solicitar um orçamento rápido com a ARB Elétrica?',
    answer: 'É muito simples e direto: basta clicar em qualquer botão "Chamar no WhatsApp" aqui na página ou ligar para (77) 9814-9375. Você pode nos enviar fotos ou vídeos do local e explicar o que precisa. Passamos o orçamento claro e transparente com rapidez!',
  },
  {
    question: 'Vocês atendem em quais cidades além de Bom Jesus da Lapa?',
    answer: 'Atendemos Bom Jesus da Lapa e toda a região em um raio de até 100km, abrangendo Serra do Ramalho, Riacho de Santana, Sítio do Mato, Paratinga, Igaporã, Macaúbas, além de fazendas, projetos de irrigação e sítios da zona rural.',
  },
  {
    question: 'Vocês realizam serviços de padrão de entrada da Coelba?',
    answer: 'Sim! Fazemos a montagem completa e adequação de padrão de entrada monofásico, bifásico e trifásico, seguindo rigorosamente todas as especificações e normas técnicas exigidas pela Neoenergia Coelba.',
  },
  {
    question: 'Qual a diferença entre um eletricista comum e um eletrotécnico?',
    answer: 'O eletrotécnico possui capacitação técnica avançada para lidar não apenas com elétrica básica residencial, mas também com projetos complexos, comandos elétricos, automação, parametrização de equipamentos, motores, inversores de frequência e correção de fator de potência.',
  },
  {
    question: 'Os serviços da ARB Elétrica possuem garantia?',
    answer: 'Com certeza! Todos os nossos serviços são executados de acordo com as normas de segurança NBR 5410 e NR-10, garantindo segurança para sua família ou empresa. Emitimos garantia registrada no serviço.',
  },
  {
    question: 'Atendem situações de emergência ou curto-circuito?',
    answer: 'Sim! Entendemos que panes elétricas, cheiro de queimado e falta de energia não podem esperar. Entre em contato imediatamente pelo telefone ou WhatsApp (77) 9814-9375 para alinharmos o atendimento o mais rápido possível.',
  },
];
