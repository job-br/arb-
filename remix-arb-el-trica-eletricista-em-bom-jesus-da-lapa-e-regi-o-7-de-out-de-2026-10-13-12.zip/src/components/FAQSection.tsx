import React, { useState } from 'react';
import { HelpCircle, ChevronDown, MessageSquare, Phone } from 'lucide-react';
import { FAQ_ITEMS, PHONE_DISPLAY, PHONE_NUMBER, WHATSAPP_NUMBER } from '../data/servicesData';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100 text-[#0B3B60] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-blue-200">
            <HelpCircle className="w-4 h-4 text-[#FF7A00]" />
            Dúvidas Frequentes
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
            Perguntas &amp; Respostas sobre <br />
            <span className="text-[#FF7A00]">Nossos Serviços Elétricos</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600">
            Tire suas dúvidas técnicas e comerciais antes de contratar.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-3.5">
          {FAQ_ITEMS.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="border border-slate-200 rounded-2xl overflow-hidden transition-all bg-slate-50/50"
              >
                <button
                  type="button"
                  onClick={() => toggle(index)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 font-bold text-slate-800 hover:text-[#0B3B60] transition-colors cursor-pointer select-none"
                >
                  <span className="text-sm sm:text-base">{item.question}</span>
                  <div
                    className={`w-7 h-7 rounded-full bg-white border border-slate-200 flex items-center justify-center flex-shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-[#0B3B60] text-white border-[#0B3B60]' : 'text-slate-600'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-4 bg-white">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions box */}
        <div className="mt-12 text-center p-8 rounded-3xl bg-blue-50 border border-blue-200">
          <h4 className="text-lg font-bold text-[#0B3B60]">
            Ficou com alguma dúvida que não está aqui?
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl mx-auto">
            Entre em contato direto pelo WhatsApp ou telefone. Tiramos todas as suas dúvidas com total clareza e atenção.
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá, tenho uma dúvida sobre um serviço elétrico.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#FF7A00] hover:bg-[#E66E00] text-white font-bold text-xs sm:text-sm shadow-md transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Chamar no WhatsApp (+55 77 9814-9375)</span>
            </a>
            <a
              href={`tel:${PHONE_NUMBER}`}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border-2 border-[#0B3B60] text-[#0B3B60] hover:bg-[#0B3B60] hover:text-white font-bold text-xs sm:text-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Ligar: {PHONE_DISPLAY}</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
