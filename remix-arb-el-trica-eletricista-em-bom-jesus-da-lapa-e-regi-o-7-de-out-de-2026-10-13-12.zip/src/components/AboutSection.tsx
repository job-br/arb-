import React from 'react';
import { Shield, CheckCircle2, Wrench, Award, FileCheck, PhoneCall, Zap, Activity } from 'lucide-react';
import { PHONE_DISPLAY, PHONE_NUMBER, WHATSAPP_NUMBER } from '../data/servicesData';
import dennisWorkImg from '../assets/images/dennis_eletrotecnico_lapa_1791373022584.jpg';
import dennisSafetyImg from '../assets/images/dennis_capacete_amb_painel_1791376971450.jpg';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 text-[#0B3B60] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-blue-200">
              <Award className="w-4 h-4 text-[#FF7A00]" />
              Compromisso com Qualidade &amp; Segurança
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
              Quem é a <span className="text-[#FF7A00]">ARB Elétrica</span>?
            </h2>
            <p className="mt-5 text-base sm:text-lg text-slate-600 leading-relaxed">
              A <strong>ARB Elétrica</strong> nasceu para suprir a necessidade de um serviço elétrico verdadeiramente técnico, pontual e transparente em <strong>Bom Jesus da Lapa e em toda a microrregião</strong>.
            </p>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              Muitas pessoas e empresas sofrem com instalações improvisadas (os famosos "gambiarras") que causam queima constante de aparelhos, risco de incêndio, desarmes inesperados e contas de energia inflacionadas.
            </p>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              Trabalhamos com metodologia profissional, ferramental calibrado de alta precisão (alicate amperímetro digital, terrômetro para medição de aterramento e detectores de tensão) e rigorosa conformidade com a <strong>NBR 5410</strong> e <strong>NR-10</strong>.
            </p>

            {/* Differentiating points */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="w-9 h-9 rounded-xl bg-[#0B3B60] text-white flex items-center justify-center mb-3">
                  <Shield className="w-5 h-5 text-[#FF7A00]" />
                </div>
                <h4 className="font-bold text-[#0B3B60] text-sm">Segurança Certificada</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Instalação de DR contra choques e DPS contra raios e queima de aparelhos.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="w-9 h-9 rounded-xl bg-[#0B3B60] text-white flex items-center justify-center mb-3">
                  <Activity className="w-5 h-5 text-[#FF7A00]" />
                </div>
                <h4 className="font-bold text-[#0B3B60] text-sm">Equilíbrio de Cargas</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Redução de desperdício térmico e economia real na conta de energia.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="w-9 h-9 rounded-xl bg-[#0B3B60] text-white flex items-center justify-center mb-3">
                  <FileCheck className="w-5 h-5 text-[#FF7A00]" />
                </div>
                <h4 className="font-bold text-[#0B3B60] text-sm">Padrão Coelba</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Adequação sem dor de cabeça conforme as exigências da concessionária.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="w-9 h-9 rounded-xl bg-[#0B3B60] text-white flex items-center justify-center mb-3">
                  <Wrench className="w-5 h-5 text-[#FF7A00]" />
                </div>
                <h4 className="font-bold text-[#0B3B60] text-sm">Eletrotécnica Especializada</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Comandos para motores, bombas d'água de poço, reversões e automações.
                </p>
              </div>
            </div>
          </div>

          {/* Right: Images of actual services & electrotechnician */}
          <div className="lg:col-span-5 space-y-6">
            <div className="relative rounded-3xl overflow-hidden border border-slate-200 shadow-xl group">
              <img
                src={dennisSafetyImg}
                alt="Dennis Barros - Eletrotécnico com capacete de proteção facial e EPIs NR-10 em manutenção pesada"
                referrerPolicy="no-referrer"
                className="w-full h-64 object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B3B60]/90 via-[#0B3B60]/20 to-transparent flex items-end p-6">
                <div>
                  <span className="text-xs font-bold text-[#FFD199] uppercase tracking-wider">
                    Segurança NR-10 &amp; Alta Confiabilidade
                  </span>
                  <h4 className="text-lg font-bold text-white">
                    Proteção com EPIs e Rigor Normativo
                  </h4>
                  <p className="text-xs text-blue-100 mt-0.5">
                    Capacete com viseira facial, luvas isolantes e ferramentas de precisão antichoque.
                  </p>
                </div>
              </div>
            </div>

            <div className="relative rounded-3xl overflow-hidden border border-slate-200 shadow-xl group">
              <img
                src={dennisWorkImg}
                alt="Dennis Barros - Eletrotécnico responsável da ARB Elétrica realizando testes com multímetro digital em quadro de comando"
                referrerPolicy="no-referrer"
                className="w-full h-64 object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B3B60]/90 via-[#0B3B60]/20 to-transparent flex items-end p-6">
                <div>
                  <span className="text-xs font-bold text-[#FFD199] uppercase tracking-wider">
                    Eletrotécnico Responsável
                  </span>
                  <h4 className="text-lg font-bold text-white">
                    Dennis Barros • ARB Elétrica
                  </h4>
                  <p className="text-xs text-blue-100 mt-0.5">
                    Diagnósticos precisos, automações e manutenções com equipamentos calibrados.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Why choose ARB Banner */}
        <div className="bg-gradient-to-r from-[#0B3B60] to-[#14476F] rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden">
          <div className="max-w-3xl relative z-10">
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              Precisa de uma avaliação no seu imóvel ou comércio?
            </h3>
            <p className="mt-2 text-sm sm:text-base text-blue-100">
              Não arrisque a segurança do seu patrimônio com curiosos. Agende agora mesmo uma visita técnica ou tire dúvidas diretamente com o profissional.
            </p>
            <div className="mt-6 flex flex-wrap gap-4">
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá Dennis, gostaria de agendar uma avaliação técnica com a ARB Elétrica.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#FF7A00] hover:bg-[#E66E00] text-white font-extrabold text-sm shadow-md transition-all"
              >
                <span>Falar no WhatsApp (+55 77 9814-9375)</span>
              </a>
              <a
                href={`tel:${PHONE_NUMBER}`}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 transition-all"
              >
                <PhoneCall className="w-4 h-4 text-[#FF7A00]" />
                <span>Ligar Agora ({PHONE_DISPLAY})</span>
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
