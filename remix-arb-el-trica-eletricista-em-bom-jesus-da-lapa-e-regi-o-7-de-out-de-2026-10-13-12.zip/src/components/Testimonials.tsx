import React from 'react';
import { Star, Quote, CheckCircle, MapPin } from 'lucide-react';
import { TESTIMONIALS } from '../data/servicesData';

export const Testimonials: React.FC = () => {
  return (
    <section id="avaliacoes" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100 text-[#0B3B60] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-blue-200">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            Avaliações e Depoimentos
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
            O Que Dizem os <span className="text-[#FF7A00]">Nossos Clientes</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600">
            A satisfação e segurança de quem já contratou a ARB Elétrica em Bom Jesus da Lapa e municípios vizinhos.
          </p>

          {/* Google 5.0 Star badge */}
          <div className="mt-6 inline-flex items-center gap-3 bg-white px-5 py-2.5 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-center gap-1 text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-amber-500" />
              ))}
            </div>
            <span className="font-extrabold text-[#0B3B60] text-sm">
              5.0 de Avaliação
            </span>
            <span className="text-xs text-slate-500 border-l border-slate-200 pl-3">
              Satisfação Garantida
            </span>
          </div>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 max-w-5xl mx-auto">
          {TESTIMONIALS.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-500" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-blue-100" />
                </div>
                <p className="text-sm sm:text-base text-slate-700 italic leading-relaxed mb-6">
                  "{item.text}"
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-[#0B3B60]">{item.name}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{item.role}</p>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                  <CheckCircle className="w-3 h-3 text-emerald-600" />
                  <span>Verificado</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
