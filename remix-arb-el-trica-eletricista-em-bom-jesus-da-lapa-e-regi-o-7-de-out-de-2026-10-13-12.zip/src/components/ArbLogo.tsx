import React from 'react';

interface ArbLogoProps {
  className?: string;
  size?: number;
  variant?: 'emblem' | 'horizontal' | 'compact';
}

export const ArbLogo: React.FC<ArbLogoProps> = ({
  className = '',
  size = 64,
  variant = 'emblem',
}) => {
  if (variant === 'horizontal') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        {/* Emblem icon */}
        <div 
          className="relative rounded-full flex items-center justify-center shadow-md bg-white border-2 border-[#0B3B60] overflow-hidden flex-shrink-0"
          style={{ width: size, height: size }}
        >
          <svg viewBox="0 0 200 200" className="w-full h-full">
            <circle cx="100" cy="100" r="95" fill="#FFFFFF" stroke="#0B3B60" strokeWidth="6" />
            <circle cx="100" cy="100" r="82" fill="none" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3,3" />
            
            {/* Center circle */}
            <circle cx="100" cy="78" r="32" fill="#0B3B60" />
            
            {/* Lightning bolt */}
            <path
              d="M104 54 L90 78 L101 78 L96 102 L114 74 L102 74 Z"
              fill="#FF7A00"
              stroke="#FFF"
              strokeWidth="1.5"
            />
            
            {/* ARB Elétrica Text */}
            <text x="100" y="130" textAnchor="middle" fontFamily="system-ui, sans-serif" fontWeight="900" fontSize="22">
              <tspan fill="#0B3B60">ARB </tspan>
              <tspan fill="#FF7A00">Elétrica</tspan>
            </text>
            <text x="100" y="146" textAnchor="middle" fontFamily="system-ui, sans-serif" fontWeight="600" fontSize="9" fill="#475569">
              Soluções Elétricas Completas
            </text>
            <text x="100" y="172" textAnchor="middle" fontFamily="system-ui, sans-serif" fontWeight="700" fontSize="10.5" fill="#0B3B60">
              Sua Parceira em Energia
            </text>
          </svg>
        </div>

        {/* Text next to logo */}
        <div className="flex flex-col">
          <div className="flex items-baseline gap-1.5">
            <span className="font-extrabold text-2xl tracking-tight text-[#0B3B60]">ARB</span>
            <span className="font-extrabold text-2xl tracking-tight text-[#FF7A00]">ELÉTRICA</span>
          </div>
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Soluções Elétricas Completas • Eletrotécnica
          </span>
        </div>
      </div>
    );
  }

  // Full detailed emblem matching the user's official badge
  return (
    <div
      className={`relative inline-flex items-center justify-center flex-shrink-0 select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 400 400"
        className="w-full h-full drop-shadow-lg"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F8FAFC" />
          </linearGradient>

          <linearGradient id="orangeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF8A00" />
            <stop offset="100%" stopColor="#EA580C" />
          </linearGradient>

          <linearGradient id="blueRing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0B3B60" />
            <stop offset="100%" stopColor="#1E4E79" />
          </linearGradient>

          {/* Curved text paths */}
          <path id="topCurve" d="M 70 200 A 130 130 0 0 1 330 200" fill="none" />
          <path id="bottomCurve" d="M 65 200 A 135 135 0 0 0 335 200" fill="none" />
          <path id="taglineCurve" d="M 90 200 A 110 110 0 0 0 310 200" fill="none" />
        </defs>

        {/* Outer navy border */}
        <circle cx="200" cy="200" r="192" fill="url(#bgGrad)" stroke="#0B3B60" strokeWidth="12" />
        <circle cx="200" cy="200" r="176" fill="none" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="6,4" />

        {/* Outer Ring Indicators */}
        {/* Top icons & text */}
        <g fill="#0B3B60" fontSize="13" fontWeight="800" fontFamily="system-ui, sans-serif" letterSpacing="2">
          {/* Top text: PREDIAL | INDUSTRIAL */}
          <text textAnchor="middle">
            <textPath href="#topCurve" startOffset="50%">
              🏢 PREDIAL   •   🏭 INDUSTRIAL
            </textPath>
          </text>
        </g>

        {/* Side Text */}
        <g fontSize="11" fontWeight="800" fontFamily="system-ui, sans-serif" fill="#0B3B60">
          {/* Left arc */}
          <text x="32" y="200" transform="rotate(-90 32 200)" textAnchor="middle" letterSpacing="1.5">
            ✓ AGILIDADE &amp; PRAZOS
          </text>
          {/* Right arc */}
          <text x="368" y="200" transform="rotate(90 368 200)" textAnchor="middle" letterSpacing="1.5">
            ☀️ GERAÇÃO DE ENERGIA ⚡
          </text>
        </g>

        {/* Bottom text: QUALIDADE & SEGURANÇA */}
        <g fill="#0B3B60" fontSize="13" fontWeight="800" fontFamily="system-ui, sans-serif" letterSpacing="2">
          <text textAnchor="middle">
            <textPath href="#bottomCurve" startOffset="50%">
              ✓ QUALIDADE &amp; SEGURANÇA ✓
            </textPath>
          </text>
        </g>

        {/* Center Circular Symbol */}
        <circle cx="200" cy="155" r="58" fill="#FFFFFF" stroke="#0B3B60" strokeWidth="10" />
        <circle cx="200" cy="155" r="50" fill="#0B3B60" />

        {/* Stylized Electric Thunderbolt in Center */}
        <path
          d="M208 115 L182 155 L202 155 L192 195 L222 148 L202 148 Z"
          fill="url(#orangeGrad)"
          stroke="#FFFFFF"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />

        {/* Glow behind lightning */}
        <circle cx="200" cy="155" r="30" fill="#FFA500" opacity="0.15" />

        {/* Main Typography */}
        <text
          x="200"
          y="250"
          textAnchor="middle"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="40"
        >
          <tspan fill="#0B3B60">ARB </tspan>
          <tspan fill="#FF7A00">Elétrica</tspan>
        </text>

        {/* Subtitle */}
        <text
          x="200"
          y="274"
          textAnchor="middle"
          fontFamily="system-ui, sans-serif"
          fontWeight="700"
          fontSize="15"
          fill="#334155"
          letterSpacing="0.5"
        >
          Soluções Elétricas Completas
        </text>

        {/* Inner Curved Badge Banner: Sua Parceira em Energia */}
        <path
          d="M 100 286 Q 200 326 300 286"
          fill="none"
          stroke="#0B3B60"
          strokeWidth="22"
          strokeLinecap="round"
        />
        <path
          d="M 100 286 Q 200 326 300 286"
          fill="none"
          id="partnerPath"
        />
        <text fill="#FFFFFF" fontSize="12" fontWeight="800" fontFamily="system-ui, sans-serif" letterSpacing="1">
          <textPath href="#partnerPath" startOffset="50%" textAnchor="middle">
            Sua Parceira em Energia
          </textPath>
        </text>

        {/* Green verified badges */}
        <circle cx="70" cy="235" r="12" fill="#10B981" />
        <path d="M65 235 L69 239 L76 231" fill="none" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

        <circle cx="330" cy="235" r="12" fill="#10B981" />
        <path d="M325 235 L329 239 L336 231" fill="none" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
};
