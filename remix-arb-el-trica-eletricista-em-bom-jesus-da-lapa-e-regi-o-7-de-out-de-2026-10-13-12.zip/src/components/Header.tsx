import React, { useState } from 'react';
import { Phone, Menu, X, Clock, MapPin } from 'lucide-react';
import { ArbLogo } from './ArbLogo';
import { PHONE_DISPLAY, PHONE_NUMBER } from '../data/servicesData';

export const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Raio de 100km', href: '#cobertura' },
    { label: 'Simulador', href: '#simulador' },
    { label: 'Diferenciais', href: '#diferenciais' },
    { label: 'Dúvidas', href: '#faq' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top emergency announcement bar */}
      <div className="bg-[#0B3B60] text-white text-xs py-2 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold text-blue-100 text-xs sm:text-[13px]">
              Plantão Elétrico em Bom Jesus da Lapa e região num raio de 100km
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px] sm:text-xs">
            <span className="hidden md:inline-flex items-center gap-1.5 text-blue-200">
              <Clock className="w-3.5 h-3.5 text-[#FF7A00]" /> Atendimento Rápido
            </span>
            <span className="hidden sm:inline-flex items-center gap-1.5 text-blue-200">
              <MapPin className="w-3.5 h-3.5 text-[#FF7A00]" /> Bom Jesus da Lapa - BA
            </span>
            <a
              href={`tel:${PHONE_NUMBER}`}
              className="font-bold text-[#FFD199] hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-[#FF7A00]" /> {PHONE_DISPLAY}
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <a
            href="#inicio"
            className="flex items-center py-2 transition-opacity hover:opacity-95"
            aria-label="ARB Elétrica - Ir para início"
          >
            <ArbLogo variant="horizontal" size={48} />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-5 lg:gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-bold text-slate-700 hover:text-[#FF7A00] py-2 transition-colors relative"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Mobile menu trigger */}
          <div className="flex md:hidden items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-100 hover:text-[#0B3B60] transition-colors focus:outline-hidden"
              aria-label={mobileMenuOpen ? 'Fechar menu de navegação' : 'Abrir menu de navegação'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-5 pt-3 pb-6 shadow-xl">
          <nav className="flex flex-col space-y-1.5">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3.5 py-2.5 rounded-xl text-sm font-bold text-slate-800 hover:bg-slate-100 hover:text-[#FF7A00] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};
