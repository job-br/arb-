import React, { useState } from 'react';
import { MessageSquare, Phone, X, Sparkles } from 'lucide-react';
import { PHONE_DISPLAY, PHONE_NUMBER, WHATSAPP_NUMBER } from '../data/servicesData';

export const WhatsAppFloatingButton: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-2.5">
      {/* Speech bubble tooltip */}
      {showTooltip && (
        <div className="bg-white rounded-2xl shadow-2xl p-3.5 border border-slate-200/90 text-slate-800 max-w-xs animate-bounce relative mb-1">
          <button
            onClick={() => setShowTooltip(false)}
            className="absolute -top-1.5 -left-1.5 w-5 h-5 bg-slate-200 hover:bg-slate-300 text-slate-600 rounded-full flex items-center justify-center text-xs"
            aria-label="Fechar aviso"
          >
            <X className="w-3 h-3" />
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse flex-shrink-0" />
            <span className="text-xs font-bold text-[#0B3B60]">Eletrotécnico Online</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 leading-snug">
            Precisa de orçamento em Bom Jesus da Lapa ou região? Clique aqui para fechar pelo WhatsApp!
          </p>
        </div>
      )}

      {/* Main Buttons Group */}
      <div className="flex items-center gap-2">
        {/* Quick Phone Call Pill */}
        <a
          href={`tel:${PHONE_NUMBER}`}
          className="hidden sm:inline-flex items-center gap-2 bg-[#0B3B60] hover:bg-[#07243B] text-white px-3.5 py-2.5 rounded-full shadow-lg text-xs font-bold transition-all border border-white/20"
          title="Ligar agora"
        >
          <Phone className="w-3.5 h-3.5 text-[#FF7A00]" />
          <span>{PHONE_DISPLAY}</span>
        </a>

        {/* WhatsApp Main Button */}
        <a
          href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá! Vim através do site da ARB Elétrica e gostaria de um orçamento rápido.')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 border-2 border-white"
          aria-label="Falar com eletricista no WhatsApp"
        >
          {/* Subtle pulse ring */}
          <span className="absolute -inset-1 rounded-full bg-[#25D366] opacity-40 animate-ping -z-10" />

          {/* SVG WhatsApp Icon */}
          <svg
            className="w-8 h-8 fill-white"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M17.472 14.382c-.301-.15-1.78-.878-2.056-.979-.276-.101-.476-.15-.677.15-.2.301-.777.979-.953 1.18-.175.2-.351.225-.652.075-.3-.15-1.268-.468-2.416-1.492-.893-.797-1.497-1.781-1.673-2.082-.175-.301-.019-.464.132-.614.136-.135.301-.351.452-.527.15-.176.2-.301.301-.502.1-.2.05-.376-.025-.526-.075-.15-.677-1.632-.928-2.235-.244-.588-.493-.508-.677-.518-.175-.008-.376-.01-.577-.01-.2 0-.526.075-.802.376-.276.301-1.053 1.029-1.053 2.509 0 1.48 1.079 2.91 1.229 3.111.15.201 2.124 3.243 5.146 4.549.719.31 1.28.496 1.718.636.723.23 1.38.198 1.9.12.58-.088 1.78-.727 2.03-1.43.25-.702.25-1.304.175-1.43-.075-.125-.276-.201-.577-.351z" />
            <path d="M12 2C6.477 2 2 6.477 2 12c0 1.821.487 3.53 1.338 5.006L2 22l5.127-1.319A9.957 9.957 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18.148c-1.605 0-3.118-.461-4.402-1.258l-.316-.192-3.266.84.872-3.14-.21-.334A8.132 8.132 0 0 1 3.852 12c0-4.492 3.655-8.148 8.148-8.148 4.492 0 8.148 3.656 8.148 8.148 0 4.492-3.656 8.148-8.148 8.148z" />
          </svg>
        </a>
      </div>
    </div>
  );
};
