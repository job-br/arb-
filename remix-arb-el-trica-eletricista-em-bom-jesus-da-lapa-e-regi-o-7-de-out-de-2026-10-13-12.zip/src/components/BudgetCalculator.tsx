import React, { useState } from 'react';
import { Calculator, CheckSquare, Send, Sparkles, Building2, Home, Factory, Tractor, ShieldCheck, MapPin } from 'lucide-react';
import { CITIES_SERVED, SERVICES_LIST, WHATSAPP_NUMBER } from '../data/servicesData';

export const BudgetCalculator: React.FC = () => {
  const [propertyType, setPropertyType] = useState<'residencial' | 'comercial' | 'predial' | 'industrial' | 'rural'>('residencial');
  const [selectedServices, setSelectedServices] = useState<string[]>([SERVICES_LIST[0].id, SERVICES_LIST[2].id]);
  const [city, setCity] = useState<string>('Bom Jesus da Lapa');
  const [clientName, setClientName] = useState<string>('');
  const [urgency, setUrgency] = useState<'normal' | 'urgente'>('normal');
  const [notes, setNotes] = useState<string>('');

  const toggleService = (id: string) => {
    if (selectedServices.includes(id)) {
      if (selectedServices.length > 1) {
        setSelectedServices(selectedServices.filter((s) => s !== id));
      }
    } else {
      setSelectedServices([...selectedServices, id]);
    }
  };

  const propertyLabels = {
    residencial: 'Casa / Apartamento (Residencial)',
    comercial: 'Comércio / Escritório / Loja',
    predial: 'Edifício / Condomínio (Predial)',
    industrial: 'Galpão / Indústria',
    rural: 'Fazenda / Sítio / Irrigação (Rural)',
  };

  // Build the formatted WhatsApp message
  const getSelectedServiceTitles = () => {
    return SERVICES_LIST
      .filter((s) => selectedServices.includes(s.id))
      .map((s) => `• ${s.title}`)
      .join('\n');
  };

  const generateWhatsAppLink = () => {
    const greeting = urgency === 'urgente' ? '🚨 *URGENTE - SOLICITAÇÃO DE SERVIÇO*' : '👋 *Olá, ARB Elétrica! Gostaria de um orçamento:*';
    const nameLine = clientName.trim() ? `\n👤 *Nome:* ${clientName.trim()}` : '';
    const propLine = `\n🏢 *Tipo de Imóvel:* ${propertyLabels[propertyType]}`;
    const cityLine = `\n📍 *Localização:* ${city} - BA`;
    const urgencyLine = urgency === 'urgente' ? '\n⚠️ *Prioridade:* Emergencial / Atendimento Imediato' : '\n📅 *Prazo:* Atendimento programado';
    const servicesListText = `\n\n⚡ *Serviços de interesse:*\n${getSelectedServiceTitles()}`;
    const notesLine = notes.trim() ? `\n\n📝 *Detalhes adicionais:*\n"${notes.trim()}"` : '';
    const footer = '\n\nPoderia me passar uma estimativa de orçamento ou disponibilidade para atendimento? Obrigado!';

    const fullText = `${greeting}${nameLine}${propLine}${cityLine}${urgencyLine}${servicesListText}${notesLine}${footer}`;
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(fullText)}`;
  };

  return (
    <section id="simulador" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-100 text-[#FF7A00] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-orange-200">
            <Calculator className="w-4 h-4" />
            Simulador Rápido e Gratuito
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
            Monte seu Orçamento em <span className="text-[#FF7A00]">1 Minuto</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600">
            Selecione o que você precisa e envie diretamente para o WhatsApp do eletrotécnico. Resposta rápida, sem burocracia e sem compromisso!
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-lg">
          {/* Step 1: Property Type */}
          <div className="mb-8">
            <label className="block text-sm font-extrabold text-[#0B3B60] uppercase tracking-wider mb-3">
              1. Qual o tipo de imóvel ou instalação?
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {[
                { id: 'residencial', label: 'Residencial', icon: Home },
                { id: 'comercial', label: 'Comercial', icon: Building2 },
                { id: 'predial', label: 'Predial', icon: Building2 },
                { id: 'industrial', label: 'Industrial', icon: Factory },
                { id: 'rural', label: 'Rural / Irrigação', icon: Tractor },
              ].map((item) => {
                const IconComponent = item.icon;
                const isSelected = propertyType === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPropertyType(item.id as any)}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                      isSelected
                        ? 'border-[#0B3B60] bg-[#0B3B60] text-white shadow-md font-bold'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 font-semibold'
                    }`}
                  >
                    <IconComponent className={`w-5 h-5 ${isSelected ? 'text-[#FF7A00]' : 'text-slate-500'}`} />
                    <span className="text-xs">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Select Services */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-extrabold text-[#0B3B60] uppercase tracking-wider">
                2. Quais serviços você precisa? (Selecione um ou mais)
              </label>
              <span className="text-xs font-semibold text-[#FF7A00]">
                {selectedServices.length} selecionado{selectedServices.length > 1 ? 's' : ''}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SERVICES_LIST.map((srv) => {
                const isChecked = selectedServices.includes(srv.id);
                return (
                  <label
                    key={srv.id}
                    onClick={() => toggleService(srv.id)}
                    className={`flex items-start gap-3 p-3.5 rounded-2xl border cursor-pointer select-none transition-all ${
                      isChecked
                        ? 'border-[#0B3B60] bg-blue-50/80 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}}
                      className="mt-1 w-4 h-4 text-[#0B3B60] rounded border-slate-300 focus:ring-[#0B3B60]"
                    />
                    <div className="flex-1">
                      <div className="text-xs sm:text-sm font-bold text-[#0B3B60]">
                        {srv.title}
                      </div>
                      <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {srv.shortDesc}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Step 3: Location and Urgency */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            <div>
              <label className="block text-sm font-extrabold text-[#0B3B60] uppercase tracking-wider mb-2">
                3. Sua Cidade / Localidade
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0B3B60]"
                >
                  {CITIES_SERVED.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} ({c.distance})
                    </option>
                  ))}
                  <option value="Outra localidade (até 100km)">Outra localidade (até 100km)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-extrabold text-[#0B3B60] uppercase tracking-wider mb-2">
                4. Urgência do Atendimento
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setUrgency('normal')}
                  className={`py-3 px-3 rounded-xl border text-xs font-bold transition-all ${
                    urgency === 'normal'
                      ? 'border-[#0B3B60] bg-[#0B3B60] text-white shadow-sm'
                      : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  📅 Programado
                </button>
                <button
                  type="button"
                  onClick={() => setUrgency('urgente')}
                  className={`py-3 px-3 rounded-xl border text-xs font-bold transition-all ${
                    urgency === 'urgente'
                      ? 'border-red-600 bg-red-600 text-white shadow-sm animate-pulse'
                      : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  🚨 Emergência / Curto
                </button>
              </div>
            </div>
          </div>

          {/* Step 4: Optional client name & observations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">
                Seu Nome (Opcional)
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Ex: João Silva"
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B3B60]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">
                Algum detalhe ou observação? (Opcional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: Disjuntor geral fica desarmando à noite..."
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B3B60]"
              />
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            <a
              href={generateWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-3 py-4 px-6 rounded-2xl bg-gradient-to-r from-[#FF7A00] to-[#E66E00] hover:from-[#E66E00] hover:to-[#D46100] text-white font-extrabold text-base sm:text-lg shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <Send className="w-5 h-5 text-white" />
              <span>Enviar Simulação no WhatsApp (+55 77 9814-9375)</span>
            </a>

            <div className="mt-4 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500 text-center">
              <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Orçamento gratuito e sem compromisso
              </span>
              <span>•</span>
              <span>Atendimento em Bom Jesus da Lapa e até 100km</span>
              <span>•</span>
              <span>Resposta em minutos</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
