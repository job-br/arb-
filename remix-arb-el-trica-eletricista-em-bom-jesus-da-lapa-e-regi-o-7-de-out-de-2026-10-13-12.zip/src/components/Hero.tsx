import React from 'react';
import { Phone, MessageSquare, ShieldCheck, MapPin, Zap, CheckCircle2, ArrowRight, Award, Clock } from 'lucide-react';
import { ArbLogo } from './ArbLogo';
import { PHONE_DISPLAY, PHONE_NUMBER, WHATSAPP_NUMBER } from '../data/servicesData';
import heroImage from '../assets/images/dennis_capacete_amb_painel_1791376971450.jpg';

export const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative bg-white pt-8 pb-16 lg:py-20 overflow-hidden">
      {/* Background Decorative Accents */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-blue-50/70 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-0 -ml-20 w-80 h-80 rounded-full bg-orange-50/60 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headlines & Call to Action */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Region & Specialization Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-[#0B3B60] text-xs sm:text-sm font-extrabold uppercase tracking-wide mb-6 shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-[#FF7A00] animate-ping" />
              <MapPin className="w-4 h-4 text-[#FF7A00]" />
              <span>Bom Jesus da Lapa e Região • Raio de 100 km</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-5xl font-black text-[#0B3B60] tracking-tight leading-[1.15]">
              Eletricista e Eletrotécnico Profissional em{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF7A00] to-[#E66E00]">
                Bom Jesus da Lapa e Região
              </span>
            </h1>

            {/* Subheadline */}
            <p className="mt-5 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Soluções Elétricas Completas para residências, condomínios prediais, comércios e indústrias. Desde novas instalações até quadros de comando, motores e manutenções emergenciais com <strong>segurança e garantia</strong>.
            </p>

            {/* Bullet Highlights */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl">
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Atendimento Residencial e Comercial</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Eletrotécnica & Comandos Elétricos</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Montagem de QDG & Padrão Coelba</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-bold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Conformidade NBR 5410 e NR-10</span>
              </div>
            </div>

            {/* Primary Action Buttons (Orange & Blue as requested) */}
            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full sm:w-auto">
              {/* WhatsApp Button (Orange) */}
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá, preciso de um orçamento com a ARB Elétrica para Bom Jesus da Lapa ou região!')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-2xl bg-gradient-to-r from-[#FF7A00] to-[#E66E00] hover:from-[#E66E00] hover:to-[#D46100] text-white font-black text-base shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <MessageSquare className="w-5 h-5 fill-white text-[#FF7A00]" />
                <span>Chamar no WhatsApp</span>
              </a>

              {/* Call button (Deep Navy Blue) */}
              <a
                href={`tel:${PHONE_NUMBER}`}
                className="inline-flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-[#0B3B60] hover:bg-[#072844] text-white font-extrabold text-base shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <Phone className="w-5 h-5 text-[#FF7A00]" />
                <span>Ligar: {PHONE_DISPLAY}</span>
              </a>
            </div>

            {/* Social Trust Metrics */}
            <div className="mt-8 pt-6 border-t border-slate-200 w-full flex flex-wrap items-center gap-6 text-xs text-slate-600">
              <div className="flex items-center gap-1.5 font-bold text-[#0B3B60]">
                <Clock className="w-4 h-4 text-[#FF7A00]" />
                <span>Atendimento Ágil em Bom Jesus da Lapa</span>
              </div>
              <div className="flex items-center gap-1.5 font-bold text-slate-700">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Serviço com Garantia por Escrito</span>
              </div>
              <div className="flex items-center gap-1.5 font-bold text-slate-700">
                <Award className="w-4 h-4 text-[#0B3B60]" />
                <span>Eletrotécnico Qualificado</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Showcase & Brand Emblem */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer decorative glow */}
              <div className="absolute -inset-2 bg-gradient-to-r from-[#0B3B60] to-[#FF7A00] rounded-3xl blur-xl opacity-20 transform -rotate-1" />

              {/* Card Container */}
              <div className="relative bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl">
                
                {/* Photo of Electrician in Action */}
                <div className="relative h-72 sm:h-84 overflow-hidden bg-slate-900 group">
                  <img
                    src={heroImage}
                    alt="Dennis Barros - Eletrotécnico profissional da ARB Elétrica em Bom Jesus da Lapa com capacete de proteção facial e EPIs NR-10"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center filter brightness-[0.98]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />
                  
                  {/* Badge over photo */}
                  <div className="absolute top-3 left-3 bg-[#0B3B60]/90 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border border-white/20">
                    <Zap className="w-3.5 h-3.5 text-[#FF7A00]" />
                    <span>SOLUÇÕES ELÉTRICAS COMPLETAS</span>
                  </div>

                  {/* Radius tag on photo */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                    <span className="font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      Segurança NR-10 &amp; Rigor Técnico
                    </span>
                    <span className="bg-[#FF7A00] font-black px-2.5 py-1 rounded-lg text-white text-[11px]">
                      24/7 Emergências
                    </span>
                  </div>
                </div>

                {/* Bottom section with Official Seal */}
                <div className="p-6 bg-white flex items-center gap-5">
                  <ArbLogo size={84} variant="emblem" className="flex-shrink-0" />
                  <div className="flex-1">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Identidade Oficial
                    </div>
                    <div className="text-xl font-black text-[#0B3B60] leading-tight">
                      ARB Elétrica
                    </div>
                    <p className="text-xs text-slate-600 mt-1">
                      Sua parceira em energia. Qualidade, agilidade e total conformidade técnica.
                    </p>
                    <a
                      href="#simulador"
                      className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-[#FF7A00] hover:text-[#E66E00]"
                    >
                      <span>Simular orçamento agora</span>
                      <ArrowRight className="w-3 h-3" />
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
