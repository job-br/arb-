import React from 'react';
import { Phone, Mail, Instagram, Facebook, MapPin, ShieldCheck, Heart, ArrowUp } from 'lucide-react';
import { ArbLogo } from './ArbLogo';
import { 
  EMAIL_ADDRESS, 
  FACEBOOK_URL, 
  INSTAGRAM_URL, 
  PHONE_DISPLAY, 
  PHONE_NUMBER, 
  WHATSAPP_NUMBER, 
  CITIES_SERVED, 
  SERVICES_LIST 
} from '../data/servicesData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contato" className="bg-[#07243B] text-slate-300 pt-16 pb-12 border-t-4 border-[#FF7A00]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-14 border-b border-slate-700/60">
          
          {/* Brand Info & Socials */}
          <div className="lg:col-span-4 space-y-5">
            <ArbLogo variant="horizontal" size={54} className="text-white" />
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-sm">
              Sua parceira em energia. Serviços elétricos e eletrotécnicos residenciais, comerciais, prediais e industriais em Bom Jesus da Lapa - BA e em um raio de até 100km.
            </p>

            {/* Social Links */}
            <div className="pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-3">
                Redes Sociais &amp; Contato Oficial:
              </span>
              <div className="flex items-center gap-3">
                {/* Instagram */}
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-[#E1306C] text-white flex items-center justify-center transition-all hover:scale-105 shadow-sm"
                  title="Instagram da ARB Elétrica (@dennis7.0)"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5" />
                </a>

                {/* Facebook */}
                <a
                  href={FACEBOOK_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-[#1877F2] text-white flex items-center justify-center transition-all hover:scale-105 shadow-sm"
                  title="Facebook da ARB Elétrica"
                  aria-label="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>

                {/* Email */}
                <a
                  href={`mailto:${EMAIL_ADDRESS}`}
                  className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-[#EA4335] text-white flex items-center justify-center transition-all hover:scale-105 shadow-sm"
                  title={`Enviar e-mail para ${EMAIL_ADDRESS}`}
                  aria-label="E-mail"
                >
                  <Mail className="w-5 h-5" />
                </a>

                {/* Phone / WhatsApp */}
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-[#25D366] text-white flex items-center justify-center transition-all hover:scale-105 shadow-sm"
                  title="WhatsApp"
                  aria-label="WhatsApp"
                >
                  <span className="font-extrabold text-sm">WA</span>
                </a>
              </div>
            </div>
          </div>

          {/* Direct Contacts List */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Canais Diretos
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-[11px] text-slate-400">Telefone / Ligação:</div>
                  <a href={`tel:${PHONE_NUMBER}`} className="font-bold text-white hover:text-[#FF7A00] transition-colors">
                    {PHONE_DISPLAY}
                  </a>
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="text-[#FF7A00] font-bold text-sm">💬</span>
                <div>
                  <div className="text-[11px] text-slate-400">WhatsApp:</div>
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold text-emerald-400 hover:text-emerald-300 transition-colors"
                  >
                    +55 77 9814-9375
                  </a>
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-[11px] text-slate-400">E-mail Comercial:</div>
                  <a href={`mailto:${EMAIL_ADDRESS}`} className="font-semibold text-slate-200 hover:text-white transition-colors break-all">
                    {EMAIL_ADDRESS}
                  </a>
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-[11px] text-slate-400">Coordenadas GPS:</div>
                  <span className="text-slate-300 font-mono text-[11px]">
                    13°15'18" S, 43°25'04" W
                  </span>
                  <div className="text-[11px] text-slate-400">
                    Bom Jesus da Lapa - Bahia
                  </div>
                </div>
              </li>
            </ul>
          </div>

          {/* Quick links to Services */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Principais Serviços
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              {SERVICES_LIST.slice(0, 6).map((s) => (
                <li key={s.id}>
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(`Olá, gostaria de saber mais sobre ${s.title}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-[#FF7A00] transition-colors flex items-center gap-1.5"
                  >
                    <span className="text-[#FF7A00]">•</span>
                    <span>{s.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Cities list in 100km radius */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Raio de 100 km
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {CITIES_SERVED.map((c) => (
                <li key={c.name} className="flex items-center gap-1.5">
                  <span className="text-[10px] text-emerald-400">✓</span>
                  <span>{c.name}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom bar with copyright and back to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <span>© {new Date().getFullYear()} <strong>ARB Elétrica</strong> - Todos os direitos reservados.</span>
            <span className="hidden sm:inline">•</span>
            <span>Bom Jesus da Lapa - BA e Região (100km)</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              NBR 5410 &amp; NR-10
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-xl bg-slate-800 hover:bg-[#FF7A00] text-white transition-colors"
              title="Voltar ao topo da página"
              aria-label="Voltar ao topo"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
