import React, { useState } from 'react';
import { MapPin, Navigation, Compass, ExternalLink, ShieldCheck, CheckCircle2, Phone, MessageSquare } from 'lucide-react';
import { CITIES_SERVED, PHONE_DISPLAY, WHATSAPP_NUMBER } from '../data/servicesData';

export const GoogleMapCoverage: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState(CITIES_SERVED[0].name);

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=-13.25500,-43.41778`;
  const googleMapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=-13.25500,-43.41778`;

  return (
    <section id="cobertura" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 text-[#0B3B60] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-blue-200">
            <Compass className="w-4 h-4 text-[#FF7A00]" />
            Área de Atendimento Regional
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
            Bom Jesus da Lapa e Região <br className="hidden sm:inline" />
            <span className="text-[#FF7A00]">num Raio de 100 km</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Atendimento presencial rápido para residências, condomínios, indústrias, comércios e propriedades rurais com deslocamento ágil e ferramentas completas.
          </p>
        </div>

        {/* Map and Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: Interactive Map Container */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="bg-white p-3 sm:p-4 rounded-2xl shadow-sm border border-slate-200 flex-1 flex flex-col">
              {/* Map header bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></span>
                  <span className="text-xs sm:text-sm font-bold text-slate-800">
                    GPS: 13°15'18" S, 43°25'04" W
                  </span>
                  <span className="hidden sm:inline-block text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">
                    -13.25500, -43.41778
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0B3B60] hover:text-[#FF7A00] transition-colors"
                  >
                    <span>Abrir no Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Embedded Google Maps iframe */}
              <div className="relative w-full h-[360px] sm:h-[440px] rounded-xl overflow-hidden bg-slate-100 border border-slate-200 shadow-inner">
                <iframe
                  title="Mapa de Atendimento ARB Elétrica - Bom Jesus da Lapa e Região"
                  src="https://maps.google.com/maps?q=-13.25500,-43.41778&hl=pt-BR&z=9&output=embed"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full filter saturate-[1.1]"
                ></iframe>

                {/* Radius badge overlay */}
                <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-xl shadow-md border border-slate-200/80 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#0B3B60] text-white flex items-center justify-center font-bold text-xs">
                    100
                  </div>
                  <div>
                    <div className="text-xs font-extrabold text-[#0B3B60] leading-none">RAIO DE 100 KM</div>
                    <div className="text-[10px] text-slate-500 font-medium">Cobertura completa</div>
                  </div>
                </div>

                {/* Direct Directions Floating Button */}
                <div className="absolute bottom-3 right-3">
                  <a
                    href={googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0B3B60] hover:bg-[#082944] text-white text-xs font-bold shadow-lg transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#FF7A00]" />
                    <span>Como Chegar</span>
                  </a>
                </div>
              </div>

              {/* Map Footer Note */}
              <div className="mt-3 pt-3 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Veículo próprio e equipe equipada para pronta resposta
                </span>
                <span className="font-medium text-slate-600">
                  Base Operacional: Bom Jesus da Lapa - Bahia
                </span>
              </div>
            </div>
          </div>

          {/* Right: Cities Served & Quick Contact */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h3 className="text-lg font-bold text-[#0B3B60] flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-[#FF7A00]" />
                Cidades e Localidades Atendidas
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mb-5 leading-relaxed">
                Você mora ou tem empresa em alguma dessas cidades? A <strong>ARB Elétrica</strong> realiza atendimento com agendamento pontual e emergencial em toda a malha regional:
              </p>

              {/* City pills list */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {CITIES_SERVED.map((city) => {
                  const isSelected = selectedCity === city.name;
                  return (
                    <button
                      key={city.name}
                      onClick={() => setSelectedCity(city.name)}
                      className={`text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-[#0B3B60] bg-blue-50/70 shadow-sm'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs sm:text-sm text-[#0B3B60] flex items-center gap-1.5">
                          <span>{city.icon}</span>
                          <span>{city.name}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {city.distance}
                        </div>
                      </div>
                      {isSelected ? (
                        <CheckCircle2 className="w-4 h-4 text-[#FF7A00] flex-shrink-0" />
                      ) : (
                        <span className="text-[10px] text-slate-400 font-bold">BA</span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Direct WhatsApp button tailored to selected city */}
              <div className="mt-6 pt-5 border-t border-slate-100">
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                    `Olá! Estou em ${selectedCity} e gostaria de solicitar um orçamento para serviço elétrico com a ARB Elétrica.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-[#FF7A00] hover:bg-[#E66E00] text-white font-bold text-sm shadow-md hover:shadow-lg transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Chamar em {selectedCity} no WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Quick Assistance Box */}
            <div className="bg-gradient-to-br from-[#0B3B60] to-[#134975] text-white p-6 rounded-2xl shadow-md">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#FF7A00] flex items-center justify-center flex-shrink-0 text-white shadow-md">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-base sm:text-lg text-white">
                    Sua cidade fica fora de Bom Jesus da Lapa?
                  </h4>
                  <p className="mt-1 text-xs sm:text-sm text-blue-100 leading-relaxed">
                    Não se preocupe! Atendemos fazendas, perímetros irrigados, comércios e residências em toda a microrregião. Ligue agora mesmo.
                  </p>
                  <div className="mt-3 flex items-center gap-3">
                    <a
                      href="tel:+557798149375"
                      className="inline-flex items-center gap-2 text-sm sm:text-base font-extrabold text-[#FFD199] hover:text-white transition-colors"
                    >
                      {PHONE_DISPLAY}
                    </a>
                    <span className="text-xs bg-white/10 px-2 py-0.5 rounded text-blue-200">
                      Ligação & WhatsApp
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
