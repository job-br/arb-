import React, { useState } from 'react';
import { 
  Building2, 
  Wrench, 
  Cpu, 
  Lightbulb, 
  ShieldCheck, 
  Plug, 
  Sliders, 
  Gauge, 
  Shield, 
  TrendingDown, 
  Scale, 
  Layers,
  ArrowRight,
  MessageSquare,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { SERVICES_LIST, WHATSAPP_NUMBER, ServiceItem } from '../data/servicesData';

interface ServicesCatalogProps {
  onSelectServiceForCalculator?: (serviceId: string) => void;
}

export const ServicesCatalog: React.FC<ServicesCatalogProps> = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'predial-residencial' | 'eletrotecnica-comandos' | 'infraestrutura-redes'>('all');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cable':
        return <Building2 className="w-6 h-6" />;
      case 'Wrench':
        return <Wrench className="w-6 h-6" />;
      case 'Cpu':
        return <Cpu className="w-6 h-6" />;
      case 'Lightbulb':
        return <Lightbulb className="w-6 h-6" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6" />;
      case 'Plug':
        return <Plug className="w-6 h-6" />;
      case 'Sliders':
        return <Sliders className="w-6 h-6" />;
      case 'Gauge':
        return <Gauge className="w-6 h-6" />;
      case 'Shield':
        return <Shield className="w-6 h-6" />;
      case 'TrendingDown':
        return <TrendingDown className="w-6 h-6" />;
      case 'Scale':
        return <Scale className="w-6 h-6" />;
      case 'Layers':
        return <Layers className="w-6 h-6" />;
      default:
        return <Cpu className="w-6 h-6" />;
    }
  };

  const filteredServices = activeCategory === 'all'
    ? SERVICES_LIST
    : SERVICES_LIST.filter(s => s.category === activeCategory);

  return (
    <section id="servicos" className="py-24 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100 text-[#0B3B60] text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 border border-blue-200">
            <span>⚡</span>
            Serviços Especializados
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B3B60] tracking-tight">
            Serviços de Eletricista e <br />
            <span className="text-[#FF7A00]">Eletrotécnico Profissional</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Atendimento residencial, predial, comercial e industrial com rigor técnico e conformidade com as normas NBR 5410, NR-10 e padrão Neoenergia Coelba.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-14">
          {[
            { id: 'all', label: 'Todos os Serviços (12)' },
            { id: 'predial-residencial', label: '🏢 Elétrica Predial e Residencial' },
            { id: 'eletrotecnica-comandos', label: '🔧 Eletrotécnica e Comandos' },
            { id: 'infraestrutura-redes', label: '🌐 Redistribuição e Infraestrutura' },
          ].map((tab) => {
            const isActive = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as any)}
                className={`px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#0B3B60] text-white shadow-md'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group hover:border-[#FF7A00]/50"
            >
              <div className="p-6 sm:p-7">
                {/* Top row: Icon and Badge */}
                <div className="flex items-center justify-between gap-3 mb-5">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#0B3B60] flex items-center justify-center group-hover:bg-[#0B3B60] group-hover:text-white transition-all duration-300 shadow-xs">
                    {getIcon(service.icon)}
                  </div>
                  {service.badge && (
                    <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-orange-100 text-[#FF7A00] border border-orange-200 uppercase tracking-wide">
                      {service.badge}
                    </span>
                  )}
                </div>

                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  {service.categoryLabel}
                </div>

                <h3 className="text-xl font-bold text-[#0B3B60] group-hover:text-[#FF7A00] transition-colors leading-snug mb-3">
                  {service.title}
                </h3>

                <p className="text-sm text-slate-600 leading-relaxed mb-5">
                  {service.fullDesc}
                </p>

                {/* Features checklist */}
                <div className="space-y-2 pt-4 border-t border-slate-100">
                  {service.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom CTA for this specific service */}
              <div className="p-6 pt-0 bg-white">
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                    `Olá, ARB Elétrica! Gostaria de um orçamento para o serviço de: *${service.title}* em Bom Jesus da Lapa ou região.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#0B3B60] hover:bg-[#FF7A00] text-white font-bold text-xs sm:text-sm shadow-xs transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Pedir Orçamento no WhatsApp</span>
                  <ArrowRight className="w-3.5 h-3.5 opacity-70 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Guarantee Bar */}
        <div className="mt-14 p-6 sm:p-8 bg-white rounded-3xl border border-slate-200 shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-lg font-extrabold text-[#0B3B60]">
                Garantia e Segurança em Todos os Serviços
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                Utilizamos instrumentos de ponta (alicate amperímetro digital, terrômetro e EPIs). Cumprimento rigoroso da NBR 5410.
              </p>
            </div>
          </div>

          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá, preciso de um eletricista profissional com urgência em Bom Jesus da Lapa!')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#FF7A00] hover:bg-[#E66E00] text-white font-bold text-sm shadow-md transition-all"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Falar com o Eletrotécnico Agora</span>
          </a>
        </div>
      </div>
    </section>
  );
};
