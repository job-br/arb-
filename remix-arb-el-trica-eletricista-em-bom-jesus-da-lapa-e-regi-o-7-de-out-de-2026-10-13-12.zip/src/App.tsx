/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ServicesCatalog } from './components/ServicesCatalog';
import { BudgetCalculator } from './components/BudgetCalculator';
import { GoogleMapCoverage } from './components/GoogleMapCoverage';
import { AboutSection } from './components/AboutSection';
import { Testimonials } from './components/Testimonials';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { 
  Zap, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  Phone, 
  MessageSquare, 
  CheckCircle,
  FileText,
  AlertTriangle,
  Flame,
  Award
} from 'lucide-react';
import { PHONE_DISPLAY, PHONE_NUMBER, WHATSAPP_NUMBER } from './data/servicesData';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col font-sans">
      {/* 1. Navbar */}
      <Header />

      {/* 2. Hero Section */}
      <main className="flex-1">
        <Hero />

        {/* 3. Quick Stats & Proof Banner */}
        <section id="diferenciais" className="bg-[#0B3B60] text-white py-12 border-y border-[#07253D]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 text-center">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-3xl sm:text-4xl font-black text-[#FF7A00] flex items-center justify-center gap-1">
                  <span>100</span>
                  <span className="text-lg font-bold text-white">km</span>
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-1">
                  Raio de Atendimento
                </div>
                <div className="text-[11px] text-blue-200 mt-0.5">
                  Bom Jesus da Lapa e região
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-3xl sm:text-4xl font-black text-[#FF7A00]">
                  100%
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-1">
                  Normas NBR 5410 &amp; NR-10
                </div>
                <div className="text-[11px] text-blue-200 mt-0.5">
                  Segurança total sem improvisos
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-3xl sm:text-4xl font-black text-[#FF7A00]">
                  24/7
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-1">
                  Plantão para Emergências
                </div>
                <div className="text-[11px] text-blue-200 mt-0.5">
                  Curtos, disjuntores e panes
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs">
                <div className="text-3xl sm:text-4xl font-black text-[#FF7A00]">
                  5.0 ★
                </div>
                <div className="text-xs sm:text-sm font-bold text-white mt-1">
                  Garantia por Escrito
                </div>
                <div className="text-[11px] text-blue-200 mt-0.5">
                  Compromisso com o cliente
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Complete Services Catalog */}
        <ServicesCatalog />

        {/* 5. Emergency Alert / Direct Contact High-Conversion Callout */}
        <section className="bg-gradient-to-r from-amber-500 via-orange-500 to-[#FF7A00] text-white py-12 shadow-inner">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center flex-shrink-0 text-white">
                  <Flame className="w-8 h-8 animate-pulse text-amber-200" />
                </div>
                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    Cheiro de queimado ou disjuntor caindo toda hora?
                  </h3>
                  <p className="text-xs sm:text-sm text-orange-100 mt-0.5">
                    Evite acidentes graves e queima de equipamentos. Desligue o disjuntor e chame agora mesmo!
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('URGENTE: Estou com problema elétrico no meu imóvel e preciso de um eletricista agora!')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-[#EA580C] hover:bg-slate-100 font-black text-sm shadow-lg transition-all"
                >
                  <MessageSquare className="w-4 h-4 fill-[#EA580C]" />
                  <span>Chamar no WhatsApp Imediatamente</span>
                </a>
                <a
                  href={`tel:${PHONE_NUMBER}`}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#0B3B60] hover:bg-[#07243B] text-white font-black text-sm shadow-lg transition-all"
                >
                  <Phone className="w-4 h-4" />
                  <span>{PHONE_DISPLAY}</span>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 6. Interactive Budget Calculator */}
        <BudgetCalculator />

        {/* 7. Google Maps & 100km Coverage Region */}
        <GoogleMapCoverage />

        {/* 8. About ARB Elétrica & Technical Standards */}
        <AboutSection />

        {/* 9. Testimonials & Google 5.0 Star Ratings */}
        <Testimonials />

        {/* 10. FAQ Accordion */}
        <FAQSection />

        {/* 11. Final Call To Action */}
        <section className="py-20 bg-gradient-to-b from-white to-slate-100 border-t border-slate-200 text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <span className="text-xs font-extrabold uppercase tracking-widest text-[#FF7A00] block mb-2">
              Sua Obra ou Reforma com Quem Entende
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0B3B60] tracking-tight">
              Pronto para Resolver Qualquer Problema Elétrico?
            </h2>
            <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto">
              Peça seu orçamento gratuito sem nenhum compromisso. Atendemos em Bom Jesus da Lapa e em toda a região num raio de 100 km.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Olá, gostaria de falar com o eletricista da ARB Elétrica para tirar dúvidas e solicitar orçamento.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-[#FF7A00] hover:bg-[#E66E00] text-white font-black text-base shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-0.5"
              >
                <MessageSquare className="w-5 h-5 fill-white text-[#FF7A00]" />
                <span>Chamar no WhatsApp (+55 77 9814-9375)</span>
              </a>

              <a
                href={`tel:${PHONE_NUMBER}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-[#0B3B60] hover:bg-[#07243B] text-white font-extrabold text-base shadow-md transition-all"
              >
                <Phone className="w-5 h-5 text-[#FF7A00]" />
                <span>Ligar: {PHONE_DISPLAY}</span>
              </a>
            </div>

            <div className="mt-8 flex items-center justify-center gap-6 text-xs text-slate-500">
              <span className="flex items-center gap-1 font-semibold text-emerald-700">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Orçamento Rápido e Transparente
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 font-semibold text-[#0B3B60]">
                <CheckCircle className="w-4 h-4 text-[#FF7A00]" />
                Garantia Técnica Comprovada
              </span>
            </div>
          </div>
        </section>
      </main>

      {/* 12. Footer with All Links & Socials */}
      <Footer />

      {/* 13. Persistent Floating WhatsApp Button */}
      <WhatsAppFloatingButton />
    </div>
  );
}
